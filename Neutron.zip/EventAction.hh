#ifndef PHOTON_DOSE_SIM_EVENT_ACTION_HH
#define PHOTON_DOSE_SIM_EVENT_ACTION_HH 1

#include "G4UserEventAction.hh"
#include "globals.hh"

namespace photon_dose_sim
{

class RunAction;

class EventAction : public G4UserEventAction
{
  public:
    explicit EventAction(RunAction* runAction);
    ~EventAction() override = default;

    void BeginOfEventAction(const G4Event* event) override;
    void EndOfEventAction(const G4Event* event) override;

    void AddEdep1(G4double edep) { fEdep1 += edep; }
    void AddEdep2(G4double edep) { fEdep2 += edep; }

  private:
    RunAction* fRunAction = nullptr;  // Only one RunAction instance
    G4double   fEdep1 = 0.;
    G4double   fEdep2 = 0.;
};

} // namespace photon_dose_sim

#endif // PHOTON_DOSE_SIM_EVENT_ACTION_HH

