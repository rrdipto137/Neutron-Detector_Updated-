#include "SteppingAction.hh"
#include "EventAction.hh"
#include "DetectorConstruction.hh"

#include "G4Step.hh"
#include "G4RunManager.hh"
#include "G4LogicalVolume.hh"

namespace photon_dose_sim
{

SteppingAction::SteppingAction(EventAction* eventAction)
    : fEventAction(eventAction)
{
}

SteppingAction::~SteppingAction()
{
}

void SteppingAction::UserSteppingAction(const G4Step* step)
{
    // Retrieve detector construction once
    if (!fScoringVolume1 || !fScoringVolume2) {
        const auto detConstruction = static_cast<const DetectorConstruction*>(
            G4RunManager::GetRunManager()->GetUserDetectorConstruction());
        fScoringVolume1 = detConstruction->GetScoringVolume1();
        fScoringVolume2 = detConstruction->GetScoringVolume2();
    }

    G4LogicalVolume* volume = step->GetPreStepPoint()->GetTouchableHandle()
                              ->GetVolume()->GetLogicalVolume();

    G4double edepStep = step->GetTotalEnergyDeposit();

    // Accumulate energy deposition in corresponding volume
    if (volume == fScoringVolume1) {
        fEventAction->AddEdep1(edepStep);
    }
    else if (volume == fScoringVolume2) {
        fEventAction->AddEdep2(edepStep);
    }
}

} // namespace photon_dose_sim

