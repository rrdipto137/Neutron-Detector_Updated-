#ifndef PhotonDoseSimPrimaryGeneratorAction_h
#define PhotonDoseSimPrimaryGeneratorAction_h 1

#include "G4VUserPrimaryGeneratorAction.hh"
#include "G4ParticleGun.hh"
#include "globals.hh"

namespace photon_dose_sim
{
    class PrimaryGeneratorAction : public G4VUserPrimaryGeneratorAction
    {
    public:
        PrimaryGeneratorAction();
        ~PrimaryGeneratorAction() override;

        void GeneratePrimaries(G4Event *anEvent) override;

        // Getter for the particle gun
        const G4ParticleGun* GetParticleGun() const { return fParticleGun; }

    private:
        G4ParticleGun *fParticleGun; // Particle gun instance
    };
}

#endif

