#ifndef PHOTON_DOSE_SIM_STEPPING_ACTION_HH
#define PHOTON_DOSE_SIM_STEPPING_ACTION_HH 1

#include "G4UserSteppingAction.hh"

class G4LogicalVolume;

namespace photon_dose_sim
{

class EventAction;

class SteppingAction : public G4UserSteppingAction
{
  public:
    explicit SteppingAction(EventAction* eventAction);
    ~SteppingAction() override;

    void UserSteppingAction(const G4Step*) override;

  private:
    EventAction* fEventAction = nullptr;

    G4LogicalVolume* fScoringVolume1 = nullptr;
    G4LogicalVolume* fScoringVolume2 = nullptr;
};

} // namespace photon_dose_sim

#endif // PHOTON_DOSE_SIM_STEPPING_ACTION_HH

