// photon-dose-sim.cc : Defines the entry point for the application.

#include "G4HadronicParameters.hh"

// User Interfaces:
#include "G4UImanager.hh"
#include "G4UIExecutive.hh"

// Run manager
#include "G4RunManagerFactory.hh"

// Visualization
#include "G4VisExecutive.hh"

// Scoring
#include "G4ScoringManager.hh"

// Other G4 classes
#include "G4SteppingVerbose.hh"
#include "QBBC.hh"
#include "Randomize.hh"

// Our own classes (Include .hh files instead of .cc files)

#include "PrimaryGeneratorAction.hh"
#include "EventAction.hh"
#include "SteppingAction.hh"
#include "RunAction.hh"

#include "NeutronHPphysics.hh"
#include "PhysicsList.cc"
#include "PhysicsList.hh"
#include "PrimaryGeneratorAction.cc"
#include "EventAction.cc"
#include "SteppingAction.cc"
#include "RunAction.cc"
#include "ActionInitialization.cc"
#include "DetectorConstruction.cc"
#include "G4ParticleHPManager.hh"
#include "NeutronHPphysics.cc"
#include "HadronElasticPhysicsHP.cc"
#include "GammaNuclearPhysicsLEND.cc"
#include "GammaNuclearPhysics.cc"
#include "RadioactiveDecayPhysics.cc"
#include "ElectromagneticPhysics.cc"
using namespace photon_dose_sim;

int  main(int argc, char** argv)

{ G4RunManager *runManager = new G4RunManager();
runManager->SetUserInitialization(new DetectorConstruction());

runManager->SetUserInitialization(new PhysicsList());
runManager->SetUserInitialization(new ActionInitialization());
G4HadronicParameters::Instance()->SetTimeThresholdForRadioactiveDecay( 1.0e+60*CLHEP::year );

runManager->Initialize();


 G4UIExecutive *ui = 0;
 
 if(argc==1){
 ui= new G4UIExecutive(argc, argv);
}
G4VisManager *vismanager =new G4VisExecutive ();
vismanager->Initialize();
G4UImanager *UImanager = G4UImanager::GetUIpointer();
if(ui)
{

 UImanager->ApplyCommand("/control/execute vis.mac");
ui->SessionStart();
}
else
{
G4String command="/control/execute ";
G4String fileName=argv[1];
UImanager->ApplyCommand(command+fileName);
}
return 0;

}

