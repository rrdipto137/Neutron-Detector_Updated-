#include "DetectorConstruction.hh"
#include "G4Tubs.hh"
#include "G4RunManager.hh"
#include "G4NistManager.hh"
#include "G4Box.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4SystemOfUnits.hh"
#include "G4Isotope.hh"
#include "G4Element.hh"
#include "G4Material.hh"
#include "G4UnitsTable.hh"
#include "G4VisAttributes.hh"
#include "G4AnalysisManager.hh"


namespace photon_dose_sim
{
    G4VPhysicalVolume* DetectorConstruction::Construct()
    {
         G4NistManager* nist = G4NistManager::Instance();

        // world properties
        G4Material* worldMaterial = nist->FindOrBuildMaterial("G4_Galactic");
        G4bool checkOverlaps = false;

        G4int worldSizeX = 70*cm;
        G4int worldSizeY = 70*cm;
        G4int worldSizeZ = 70*cm;


        // define worlds
        auto solidWorld = new G4Box("World",
            worldSizeX,                 // default is mm (it seems like)
            worldSizeY,
            worldSizeZ);

        auto logicWorld = new G4LogicalVolume(solidWorld,
            worldMaterial, "World");

        auto physWorld = new G4PVPlacement(nullptr,  // no rotation
            G4ThreeVector(),                           // at (0,0,0)
            logicWorld,                                // its logical volume
            "World",                                   // its name
            nullptr,                                   // its mother  volume
            false,                                     // no boolean operation
            0,                                         // copy number
            checkOverlaps);                            // overlaps checking

        
        

   
       // First Detector
     G4Material*detector1Material = nist->FindOrBuildMaterial("G4_SODIUM_IODIDE");
     
   
        G4double detector1SizeX = 4 ;
        G4double detector1SizeY = 4 ;
        G4double detector1SizeZ = 4 * cm;
        G4ThreeVector detector1Pos = G4ThreeVector(0, 0, 10 * cm);

        auto solidDetector1 = new G4Box("Detector1",
            detector1SizeX,
            detector1SizeY,
            detector1SizeZ);

        auto logicDetector1 = new G4LogicalVolume(solidDetector1,
            detector1Material,
            "Detector1");

        new G4PVPlacement(nullptr,    // rotation
            detector1Pos,              // position
            logicDetector1,           // its logical volume
            "Detector1",              // its name
            logicWorld,               // its mother  volume
            false,                    // boolean operation
            0,                        // copy number
            checkOverlaps);           // overlaps checking

      
      //collimator
      
      
    /*  // Define collimator material (Lead)
G4Material* collimatorMaterial = nist->FindOrBuildMaterial("G4_Pb");

// Define collimator dimensions
G4double collimatorOuterRadius = 5.0 * cm; // Outer radius
G4double collimatorInnerRadius = 0.5 * cm; // Aperture (hole) radius
G4double collimatorHeight = 10.0 * cm;     // Thickness of the collimator

// Create collimator geometry (hollow cylinder)
auto solidCollimator = new G4Tubs("Collimator",
    collimatorInnerRadius,  // Inner radius (hole)
    collimatorOuterRadius,  // Outer radius
    collimatorHeight / 2.0, // Half-height
    0.0,                    // Start angle
    360.0 * deg);           // Full cylinder

// Create logical volume
auto logicCollimator = new G4LogicalVolume(solidCollimator,
    collimatorMaterial,
    "Collimator");

// Place the collimator at the source position
G4ThreeVector collimatorPos = G4ThreeVector(0, 0, 0 * cm);
new G4PVPlacement(nullptr,  // No rotation
    collimatorPos,          // Position at source
    logicCollimator,        // Logical volume
    "Collimator",           // Name
    logicWorld,             // Mother volume
    false,                  // No boolean operations
    0,                      // Copy number
    checkOverlaps);         // Check overlaps

    
     
      */
      
            
      
      
         //Shield of polyboron
  /*
  
G4double polyboronDensity = 0.971 * g/cm3;
G4Material* polyboronMaterial = new G4Material("Polyboron", polyboronDensity, 4);

polyboronMaterial->AddElement(nist->FindOrBuildElement("H"), 12.38 * perCent);
polyboronMaterial->AddElement(nist->FindOrBuildElement("B"), 4.89 * perCent);
polyboronMaterial->AddElement(nist->FindOrBuildElement("C"), 59.88 * perCent);
polyboronMaterial->AddElement(nist->FindOrBuildElement("O"), 22.85 * perCent);

G4double leadSizeX = worldSizeX;
G4double leadSizeY = worldSizeY;
G4double leadSizeZ = 1 * cm; // Adjust the thickness of the lead shield as needed

auto solidLead = new G4Box("LeadShield",
    leadSizeX,
    leadSizeY,
    leadSizeZ);

auto logicLead = new G4LogicalVolume(solidLead,
    polyboronMaterial,
    "LeadShield");

G4ThreeVector leadPos = G4ThreeVector(0, 0, 22.5 * cm); // Position lead shield between the detectors
new G4PVPlacement(nullptr,
    leadPos,
    logicLead,
    "LeadShield",
    logicWorld,
    false,
    0,
    checkOverlaps);

     
      
    */
    
   /// TN-32 Resin shield
   
// Define an Element from isotopes, by relative abundance
G4int iz, n;  // iz = number of protons in an isotope; n = number of nucleons in an isotope;
G4int ncomponents;
G4double abundance;

G4Isotope* B10 = new G4Isotope("B10", iz = 5, n = 10, 10.01 * g / mole);
G4Isotope* B11 = new G4Isotope("B11", iz = 5, n = 11, 11.01 * g / mole);

G4Element* B = new G4Element("Boron", "B", ncomponents = 2);
B->AddIsotope(B10, abundance = 19.9 * perCent);
B->AddIsotope(B11, abundance = 80.1 * perCent);

G4Element* Al = nist->FindOrBuildElement(13);
G4Element* C  = nist->FindOrBuildElement(6);
G4Element* O  = nist->FindOrBuildElement(8);
G4Element* H  = nist->FindOrBuildElement(1);

G4double totalMass = 337.40;
G4double tn32Density = totalMass * g / cm3;
G4Material* tn32Material = new G4Material("TN32Resin", tn32Density, 5);

tn32Material->AddElement(Al, 118.20 / totalMass);
tn32Material->AddElement(C, 52.61 / totalMass);
tn32Material->AddElement(O, 70.08 / totalMass);
tn32Material->AddElement(H, 4.42 / totalMass);
tn32Material->AddElement(B, (43.86 + 48.23) / totalMass);

G4double resinSizeX = worldSizeX;
G4double resinSizeY = worldSizeY;
G4double resinSizeZ = 3 * cm; // Adjust the thickness to 3 cm

auto solidResin = new G4Box("TN32Resin", resinSizeX, resinSizeY, resinSizeZ);

auto logicResin = new G4LogicalVolume(solidResin, tn32Material, "TN32Resin");

G4ThreeVector resinPos = G4ThreeVector(0, 0, 20 * cm);
new G4PVPlacement(nullptr, resinPos, logicResin, "TN32Resin", logicWorld, false, 0, checkOverlaps);



  

        
        
        
        
        
        
        
        
        // Second Detector 
    // Define helium-4 material
G4double helium4Density = 29481 * g/cm3;
G4double helium4Pressure = 180 * atmosphere;
G4double helium4Temperature = 24.7 * CLHEP::kelvin + CLHEP::STP_Temperature;
G4Material* helium4 = new G4Material("Helium4", helium4Density, 1, kStateGas, helium4Temperature, helium4Pressure);
helium4->AddElement(nist->FindOrBuildElement("He"), 100 * perCent);

// Define Li-6 coating material
G4double Li6Density = 1.51 * g/cm3;
G4Material* Li6 = new G4Material("Li6", Li6Density, 1);
Li6->AddElement(nist->FindOrBuildElement("Li"), 100 * perCent);




// Define cylindrical detector dimensions
G4double detectorRadius = 30.608 * cm;
G4double detectorHeight = 60.828 * cm;
G4ThreeVector detectorPosition = G4ThreeVector(0, 0, 50* cm); // Positioned 27 cm along z-axis





// Create cylinder for helium-4 active volume
G4Tubs* solidDetector = new G4Tubs("Detector",
    0,                     // Inner radius
    detectorRadius,        // Outer radius
    detectorHeight / 2.0,  // Half-height
    0.0,                   // Starting angle
    360.0 * deg);          // Sweeping angle

// Create logical volume for helium-4 active volume
G4LogicalVolume* logicDetector = new G4LogicalVolume(solidDetector,
    helium4,            // Material: Helium-4
    "Detector");       // Name

// Place the detector volume in the world
new G4PVPlacement(new G4RotationMatrix( 90 * deg,90*deg,0), // Rotate 90 degrees about the X-axis
    detectorPosition,                 // Position
    logicDetector,                    // Logical volume
    "Detector",                      // Name
    logicWorld,                       // Mother volume
    false,                            // Boolean operation
    1,                                // Copy number
    checkOverlaps);                   // Overlap checking

// Define Li-6 coating dimensions
G4double coatingThickness = 10 * micrometer;
G4Tubs* solidCoating = new G4Tubs("Li6Coating",
    detectorRadius - coatingThickness, // Inner radius
    detectorRadius,                    // Outer radius
    detectorHeight / 2.0,              // Half-height
    0.0,                               // Starting angle
    360.0 * deg);                      // Sweeping angle

// Create logical volume for Li-6 coating
G4LogicalVolume* logicCoating = new G4LogicalVolume(solidCoating,
    Li6,                  // Material: Li-6
    "Li6Coating");       // Name

// Place the Li-6 coating volume inside the helium-4 volume
new G4PVPlacement(nullptr,            // No rotation
    G4ThreeVector(),                  // Same position as the helium volume
    logicCoating,                     // Logical volume
    "Li6Coating",                    // Name
    logicDetector,                    // Mother volume
    false,                            // Boolean operation
    1,                                // Copy number
    checkOverlaps);                   // Overlap checking





/*
// Define red color for detectors
G4VisAttributes* redColor = new G4VisAttributes(G4Colour(1.0, 0.0, 0.0)); // Red

// Ensure full visibility
redColor->SetVisibility(true);
redColor->SetForceSolid(true); // Makes the volume solid
redColor->SetForceAuxEdgeVisible(true); // Show edges for clarity

// Apply red color to all detector components
logicDetector1->SetVisAttributes(redColor);  // First detector (NaI)
logicDetector->SetVisAttributes(redColor);   // Second detector (Helium-4)
logicCoating->SetVisAttributes(redColor);    // Li-6 coating (inside second detector)


*/





        // Set scoring volumes
        fScoringVolume1= logicDetector;
         fScoringVolume2= logicDetector1;
        
       
        return physWorld;
    }
}

